var body = document.getElementsByTagName('body');

for (i = 0; i <= 0; i++) {
    
    body.innerHTML = 
    "<pre>"+
    "var prd01 = { prdName:\"Tropical Palm \" + productType[0],"+
                  "prdImage: \"IMAGE GOES HERE\","+
                  "prdPrice: \"90 \" + currency,"+
                  "prdCode: \"190952CZ\""+
                "};"+
    "</pre>"
    
    
}